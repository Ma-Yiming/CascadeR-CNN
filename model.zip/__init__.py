import torchvision as tv
from collections import OrderedDict


def rpn(
        channel=512, fg_iou=0.7, bg_iou=0.3, batch=256,
        sizes=((32, 64, 128, 256, 512),),
        ratios=((0.5, 1.0, 2.0),), p=0.5, nms=0.7,
        pre_nms_train=2000, pre_nms_test=1000,
        post_nms_train=2000, post_nms_test=1000
):
    anchor = tv.models.detection.anchor_utils.AnchorGenerator(sizes, ratios)
    head = tv.models.detection.rpn.RPNHead(
        channel, anchor.num_anchors_per_location()[0]
    )
    pre_nms = {"training": pre_nms_train, "testing": pre_nms_test}
    post_nms = {"training": post_nms_train, "testing": post_nms_test}
    return tv.models.detection.rpn.RegionProposalNetwork(
        anchor, head, fg_iou, bg_iou, batch, p, pre_nms, post_nms, nms
    )


def net(
        num, iou, name=("0", "1", "2", "3"), channel=7, sp=2,
        out_channel=512, batch=512, bpf=0.25, brw=None, score=0.05, nms=0.1, per=100
):
    fg, bg = iou, 1 - iou
    roi_pool = tv.ops.poolers.MultiScaleRoIAlign(list(name), channel, sp)
    n = roi_pool.output_size[0]
    box_head = tv.models.detection.faster_rcnn.TwoMLPHead(out_channel * n ** 2, 1024)
    box_predictor = tv.models.detection.faster_rcnn.FastRCNNPredictor(1024, num)
    return tv.models.detection.roi_heads.RoIHeads(
        roi_pool, box_head, box_predictor, fg, bg, batch, bpf, brw, score, nms, per
    )


def vgg16():
    return tv.models.vgg16(True).features


def transform(minimal=480, maximum=640, mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)):
    return tv.models.detection.transform.GeneralizedRCNNTransform(minimal, maximum, mean, std)
