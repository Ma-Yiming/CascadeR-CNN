import model
import torch
from torchvision.models import detection


class Head(torch.nn.Module):
    def __init__(self, rpn=None):
        super().__init__()
        self.rpn = model.rpn()
        self.feature = model.vgg16()
        self.transform = model.transform()
        if rpn:
            self.rpn.load_state_dict(torch.load(rpn))
        self.sizes = None
        self.images = None
        self.targets = None
        self.features = None
        self.proposals = None

    def forward(self, images, targets=None):
        self.images, self.targets = self.transform(images, targets)
        self.features = self.feature(self.images.tensors)
        self.features = model.OrderedDict([("0", self.features)])
        return self.rpn(self.images, self.features, self.targets)


class Net(torch.nn.Module):
    def __init__(self, number, iou, pkl=None):
        self.iou = iou
        super(Net, self).__init__()
        self.net = model.net(number, iou)
        if pkl:
            self.net.load_state_dict(torch.load(pkl))

    def forward(self, features, proposals, sizes, targets=None):
        return self.net(features, proposals, sizes, targets)


class FasterRCNN(Head):
    def __init__(self, number, iou, rpn=None, pkl=None):
        super().__init__(rpn)
        self.net = Net(number, iou, pkl)

    def forward(self, images, targets=None):
        self.sizes = [(image.shape[-2], image.shape[-1]) for image in images]
        self.proposals = super().forward(images, targets)[0]
        return self.net(self.features, self.proposals, self.images.image_sizes, self.targets)


class CascadeNet(FasterRCNN):
    def __init__(self, number, iou1, iou2, rpn=None, net0=None, cascade=None):
        super().__init__(number, iou1, rpn, net0)
        self.cascade = Net(number, iou2, cascade)

    def forward(self, images, targets=None):
        if targets is not None:
            self.net.eval()
        self.proposals = [super().forward(images, targets)[0][0]["boxes"]]
        return self.cascade(self.features, self.proposals, self.images.image_sizes, self.targets)


class CascadeRCNN(CascadeNet):
    def __init__(self, number, iou1, iou2, iou3, rpn, net0, cascade, tail):
        super().__init__(number, iou1, iou2, rpn, net0, cascade)
        self.tail = Net(number, iou3, tail)

    def forward(self, images, targets=None):
        if targets is not None:
            self.cascade.eval()
        self.proposals = [super().forward(images, targets)[0][0]["boxes"]]
        detections, losses = \
            self.tail(self.features, self.proposals, self.images.image_sizes, self.targets)
        detections = self.transform.postprocess(
            detections, self.images.image_sizes, self.sizes
        )
        return detections, losses
